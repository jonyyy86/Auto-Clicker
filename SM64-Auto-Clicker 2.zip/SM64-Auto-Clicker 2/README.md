# SM64 Auto Clicker

Native SwiftUI iOS project with bundle identifier `com.smd.sm64ios`.

## Included
- Click trainer with adjustable CPS, start/pause/stop, and click counter
- Macro recorder/replay for tap sequences **inside this app**
- Multiple configurable target points for the in-app trainer
- Randomized delay option
- Saved presets using local app storage
- Dark premium interface

## Important iOS limitation
A regular App Store-style iOS app cannot draw a system-wide floating overlay or inject touch events into Roblox or other third-party apps. This project therefore implements a working click trainer and macro playback **inside its own screen**. It does not bypass iOS sandboxing or automate other apps. For supported cross-app accessibility workflows, configure Apple's Switch Control / AssistiveTouch separately in iOS Settings.

## Build locally
Open `SM64AutoClicker.xcodeproj` in Xcode, select an iOS Simulator or device, then build. Set your Team and signing settings in Xcode for device installation.

## Build with GitHub Actions
1. Push this repository to GitHub.
2. Open **Actions** → **Build SM64 Auto Clicker IPA** → **Run workflow**.
3. Download the `SM64AutoClicker-unsigned-ipa` artifact.
4. Sign the unsigned IPA with your own signing tool/certificate before installing.

The workflow creates an unsigned IPA package. It does not include an Apple signing certificate or provisioning profile.
