import SwiftUI

struct TapPoint: Identifiable, Codable, Equatable {
    var id = UUID()
    var name: String
    var x: Double
    var y: Double
    var enabled: Bool = true
}

struct TapPreset: Identifiable, Codable {
    var id = UUID()
    var name: String
    var cps: Double
    var randomDelay: Bool
    var points: [TapPoint]
}

struct MacroStep: Identifiable, Codable {
    var id = UUID()
    var pointName: String
    var delay: Double
}

struct ContentView: View {
    @AppStorage("sm64_cps") private var cps = 10.0
    @AppStorage("sm64_random") private var randomDelay = false
    @AppStorage("sm64_presets") private var presetsData = Data()
    @State private var points = [
        TapPoint(name: "Target 1", x: 0.5, y: 0.5),
        TapPoint(name: "Target 2", x: 0.3, y: 0.7, enabled: false)
    ]
    @State private var running = false
    @State private var clickCount = 0
    @State private var macroRecording = false
    @State private var macroSteps: [MacroStep] = []
    @State private var status = "Ready"
    @State private var timer: Timer?
    @State private var showPresetName = false
    @State private var presetName = ""

    private var presets: [TapPreset] {
        (try? JSONDecoder().decode([TapPreset].self, from: presetsData)) ?? []
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.035, green: 0.05, blue: 0.10), Color(red: 0.07, green: 0.10, blue: 0.19)], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            ScrollView {
                VStack(spacing: 18) {
                    header
                    clickerCard
                    macroCard
                    targetsCard
                    settingsCard
                    presetsCard
                    Text("In-app touch trainer • iOS does not allow this app to tap inside other apps")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.white.opacity(0.42))
                        .multilineTextAlignment(.center)
                        .padding(.bottom, 22)
                }
                .padding(18)
            }
        }
        .onDisappear { stopClicking() }
        .alert("Save preset", isPresented: $showPresetName) {
            TextField("Preset name", text: $presetName)
            Button("Save") { savePreset() }
            Button("Cancel", role: .cancel) {}
        } message: { Text("Save your current speed and target settings.") }
    }

    private var header: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 17).fill(Color.cyan.opacity(0.16))
                Image(systemName: "hand.tap.fill").font(.system(size: 25, weight: .bold)).foregroundStyle(.cyan)
            }.frame(width: 54, height: 54)
            VStack(alignment: .leading, spacing: 3) {
                Text("SM64 AUTO CLICKER").font(.system(size: 17, weight: .black, design: .rounded)).tracking(1.1)
                Text("Precision tap studio").font(.caption).foregroundStyle(.white.opacity(0.55))
            }
            Spacer()
            Circle().fill(running ? .green : .gray).frame(width: 8, height: 8)
            Text(running ? "ACTIVE" : "READY").font(.system(size: 10, weight: .bold)).foregroundStyle(running ? .green : .white.opacity(0.5))
        }
        .foregroundStyle(.white)
        .padding(.vertical, 6)
    }

    private var clickerCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            sectionTitle("AUTO CLICKER", icon: "bolt.fill")
            HStack(alignment: .lastTextBaseline) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("CLICK SPEED").font(.system(size: 10, weight: .bold)).foregroundStyle(.white.opacity(0.48))
                    HStack(alignment: .firstTextBaseline, spacing: 5) {
                        Text("\(Int(cps))").font(.system(size: 48, weight: .black, design: .rounded)).monospacedDigit()
                        Text("CPS").font(.caption.bold()).foregroundStyle(.cyan)
                    }
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 3) {
                    Text("TOTAL CLICKS").font(.system(size: 10, weight: .bold)).foregroundStyle(.white.opacity(0.48))
                    Text("\(clickCount)").font(.system(size: 27, weight: .bold, design: .rounded)).monospacedDigit()
                }
            }
            Slider(value: $cps, in: 1...30, step: 1).tint(.cyan)
            HStack {
                Text("1 CPS"); Spacer(); Text("30 CPS")
            }.font(.system(size: 10, weight: .medium)).foregroundStyle(.white.opacity(0.4))
            HStack(spacing: 10) {
                Button(action: { running ? pauseClicking() : startClicking() }) {
                    Label(running ? "PAUSE" : "START", systemImage: running ? "pause.fill" : "play.fill")
                        .frame(maxWidth: .infinity).padding(.vertical, 14)
                }
                .buttonStyle(GlowButton(color: .cyan))
                Button(action: stopClicking) {
                    Image(systemName: "stop.fill").frame(width: 52, height: 48)
                }.buttonStyle(GlowButton(color: .pink))
            }
            Text(status).font(.caption).foregroundStyle(.white.opacity(0.55))
        }.panel()
    }

    private var macroCard: some View {
        VStack(alignment: .leading, spacing: 13) {
            sectionTitle("MACRO RECORDER", icon: "point.topleft.down.curvedto.point.bottomright.up")
            Text("Record and replay a sequence in the trainer area below. Macro playback is local to this app.")
                .font(.caption).foregroundStyle(.white.opacity(0.55))
            HStack(spacing: 9) {
                Button {
                    macroRecording.toggle()
                    status = macroRecording ? "Recording macro…" : "Macro recording stopped"
                } label: {
                    Label(macroRecording ? "FINISH" : "RECORD", systemImage: macroRecording ? "stop.circle.fill" : "record.circle")
                        .frame(maxWidth: .infinity).padding(.vertical, 12)
                }.buttonStyle(GlowButton(color: .pink))
                Button(action: replayMacro) {
                    Label("REPLAY", systemImage: "arrow.clockwise").frame(maxWidth: .infinity).padding(.vertical, 12)
                }.buttonStyle(GlowButton(color: .purple))
            }
            Text("\(macroSteps.count) recorded steps").font(.caption2).foregroundStyle(.white.opacity(0.45))
        }.panel()
    }

    private var targetsCard: some View {
        VStack(alignment: .leading, spacing: 13) {
            HStack {
                sectionTitle("MULTI-TARGETS", icon: "scope")
                Spacer()
                Button { points.append(TapPoint(name: "Target \(points.count + 1)", x: 0.5, y: 0.5)) } label: {
                    Label("ADD", systemImage: "plus").font(.system(size: 10, weight: .bold)).foregroundStyle(.cyan)
                }
            }
            ForEach($points) { $point in
                HStack(spacing: 10) {
                    Toggle("", isOn: $point.enabled).labelsHidden().tint(.cyan).scaleEffect(0.8)
                    TextField("Target name", text: $point.name).font(.subheadline.weight(.semibold))
                    Text("X").font(.caption2).foregroundStyle(.white.opacity(0.4))
                    TextField("0.5", value: $point.x, format: .number).keyboardType(.decimalPad).frame(width: 42)
                    Text("Y").font(.caption2).foregroundStyle(.white.opacity(0.4))
                    TextField("0.5", value: $point.y, format: .number).keyboardType(.decimalPad).frame(width: 42)
                    Button { points.removeAll { $0.id == point.id } } label: {
                        Image(systemName: "trash").foregroundStyle(.pink.opacity(0.8))
                    }
                }
                .font(.caption)
                .padding(9)
                .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 10))
            }
            Button(action: simulateTargetTap) {
                Label("TEST ENABLED TARGETS", systemImage: "hand.tap").frame(maxWidth: .infinity).padding(.vertical, 12)
            }.buttonStyle(GlowButton(color: .blue))
        }.panel()
    }

    private var settingsCard: some View {
        VStack(alignment: .leading, spacing: 13) {
            sectionTitle("CLICK BEHAVIOR", icon: "slider.horizontal.3")
            Toggle(isOn: $randomDelay) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Randomized delay").font(.subheadline.weight(.semibold))
                    Text("Adds a small timing variation to trainer clicks").font(.caption2).foregroundStyle(.white.opacity(0.45))
                }
            }.tint(.cyan)
            Button { clickCount = 0; status = "Counter reset" } label: {
                Label("RESET CLICK COUNTER", systemImage: "arrow.counterclockwise")
                    .font(.system(size: 11, weight: .bold)).frame(maxWidth: .infinity).padding(.vertical, 11)
            }.buttonStyle(GlowButton(color: .gray))
        }.panel()
    }

    private var presetsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                sectionTitle("PRESETS", icon: "bookmark.fill")
                Spacer()
                Button { presetName = ""; showPresetName = true } label: {
                    Label("SAVE CURRENT", systemImage: "plus").font(.system(size: 10, weight: .bold)).foregroundStyle(.cyan)
                }
            }
            if presets.isEmpty {
                Text("No saved presets yet. Save your current setup above.")
                    .font(.caption).foregroundStyle(.white.opacity(0.45))
            } else {
                ForEach(presets) { preset in
                    HStack {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(preset.name).font(.subheadline.bold())
                            Text("\(Int(preset.cps)) CPS • \(preset.points.count) targets")
                                .font(.caption2).foregroundStyle(.white.opacity(0.45))
                        }
                        Spacer()
                        Button("LOAD") {
                            cps = preset.cps; randomDelay = preset.randomDelay; points = preset.points
                        }.font(.system(size: 10, weight: .black)).foregroundStyle(.cyan)
                    }.padding(10).background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 10))
                }
            }
        }.panel()
    }

    private func sectionTitle(_ title: String, icon: String) -> some View {
        Label(title, systemImage: icon).font(.system(size: 11, weight: .black)).tracking(1).foregroundStyle(.cyan)
    }

    private func startClicking() {
        running = true
        status = "Trainer running — tap events stay inside this app"
        scheduleTick()
    }

    private func pauseClicking() {
        running = false
        timer?.invalidate()
        timer = nil
        status = "Paused"
    }

    private func stopClicking() {
        running = false
        timer?.invalidate()
        timer = nil
        if status != "Ready" { status = "Stopped" }
    }

    private func scheduleTick() {
        timer?.invalidate()
        guard running else { return }
        let base = 1.0 / cps
        let delay = randomDelay ? base * Double.random(in: 0.8...1.2) : base
        timer = Timer.scheduledTimer(withTimeInterval: max(0.03, delay), repeats: false) { _ in
            clickCount += 1
            if macroRecording {
                macroSteps.append(MacroStep(pointName: points.first(where: \.enabled)?.name ?? "Target", delay: delay))
            }
            scheduleTick()
        }
    }

    private func simulateTargetTap() {
        let active = points.filter(\.enabled)
        clickCount += active.count
        if macroRecording {
            for p in active { macroSteps.append(MacroStep(pointName: p.name, delay: 0.1)) }
        }
        status = "Tested \(active.count) enabled targets inside the trainer"
    }

    private func replayMacro() {
        guard !macroSteps.isEmpty else { status = "Record a macro first"; return }
        clickCount += macroSteps.count
        status = "Replayed \(macroSteps.count) macro steps in the trainer"
    }

    private func savePreset() {
        guard !presetName.trimmingCharacters(in: .whitespaces).isEmpty else { return }
        var all = presets
        all.append(TapPreset(name: presetName, cps: cps, randomDelay: randomDelay, points: points))
        presetsData = (try? JSONEncoder().encode(all)) ?? Data()
        status = "Preset saved"
    }
}

struct GlowButton: ButtonStyle {
    var color: Color
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 12, weight: .black, design: .rounded))
            .foregroundStyle(.white)
            .background(color.opacity(configuration.isPressed ? 0.22 : 0.13), in: RoundedRectangle(cornerRadius: 13))
            .overlay(RoundedRectangle(cornerRadius: 13).stroke(color.opacity(0.55), lineWidth: 1))
            .shadow(color: color.opacity(0.12), radius: 9)
            .scaleEffect(configuration.isPressed ? 0.98 : 1)
    }
}

extension View {
    func panel() -> some View {
        self.padding(16)
            .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 20))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(.white.opacity(0.08), lineWidth: 1))
    }
}
